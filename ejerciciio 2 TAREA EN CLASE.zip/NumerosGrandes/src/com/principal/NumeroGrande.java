package com.principal;

public class NumeroGrande {
	private String num;
	private int[]digito= new int[15];
	
	public NumeroGrande(String num) {
		this.num=num;
		
		
	}
	
	public boolean mayor(NumeroGrande b) {
		boolean temp=false;
		for(int i=0; i<15; i++) {
			if(digito[i]>b.digito[i]) {
				temp=true;
				break;
			}
		}
		return temp;
	}
	
	public boolean menor(NumeroGrande b) {
		boolean temp=false;
		for(int i=0; i<15; i++) {
				if(digito[i]<b.digito[i]) {
					temp=true;
				}
		}
		return temp;
	}
	
	public boolean igual(NumeroGrande b) {
		boolean temp=true;
		for(int i=0; i<15; i++) {
			if(digito[i]!=b.digito[i]) {
				temp=false;
				break;
			}
		}
		return temp;
	}
	
	
	public void escribir() {
		char []digi=num.toCharArray();
		for(int i=0;i<15;i++) {
				digito[i]=(int)digi[i]-48;
		}
	}
	
	public void imprimir() {
		for(int i=0; i<15;i++) {
			System.out.print(digito[i]);
		}
		System.out.println();
	}

	public int getDigito(int a) {
		return digito[a];
	}

	public void setDigito(int index,int a) {
		this.digito[index] = a;
	}
	
	
}
