package com.principal;

import java.util.Scanner;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner aux=new Scanner(System.in);
		String cadena;
		OperacionesNum operaciones = new OperacionesNum();
		
		System.out.println("Ingrese el primer n�mero");
		cadena=aux.next();
		NumeroGrande a=new NumeroGrande(cadena);
		a.escribir();
		System.out.println("Ingrese el segundo n�mero");
		cadena=aux.next();
		NumeroGrande b=new NumeroGrande(cadena);
		b.escribir();
		NumeroGrande c=new NumeroGrande("000000000000000");
		c.escribir();
		
		System.out.println("a>b:");
		System.out.println(a.mayor(b));
		System.out.println("b<a:");
		System.out.println(a.menor(b));
		System.out.println("a==b:");
		System.out.println(a.igual(b));
		
		c=operaciones.sumar(a, b);
		System.out.println("a+b: ");
		c.imprimir();
		c=operaciones.restar(a, b);
		System.out.println("a-b: ");
		c.imprimir();
	}

}
