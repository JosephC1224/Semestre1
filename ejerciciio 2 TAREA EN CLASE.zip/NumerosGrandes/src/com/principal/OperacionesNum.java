package com.principal;

public class OperacionesNum {
	
	public NumeroGrande sumar(NumeroGrande a,NumeroGrande b) {
		NumeroGrande temp=new NumeroGrande("000000000000000");
		temp.escribir();
		for(int i=14;i>=0;i--) {
			if(a.getDigito(i)+b.getDigito(i)<10) {
				temp.setDigito(i,a.getDigito(i)+b.getDigito(i));
			}else {
				temp.setDigito(i,a.getDigito(i)+b.getDigito(i)-10);
				temp.setDigito(i-1,temp.getDigito(i-1)+1);
			}
		}
		
		return temp;
	}
	
	public NumeroGrande restar(NumeroGrande a,NumeroGrande b) {
		NumeroGrande temp=new NumeroGrande("000000000000000");
		
		for(int i=14;i>0;i--) {
			if(a.getDigito(i)-b.getDigito(i)>=0) {
				temp.setDigito(i, a.getDigito(i)-b.getDigito(i));
			}else {
				temp.setDigito(i, (a.getDigito(i)+10)-b.getDigito(i));
				b.setDigito(i-1, b.getDigito(i-1)+1);
			}
		}
		
		return temp;
	}
}
